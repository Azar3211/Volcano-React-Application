
function Footer() {

    return (
        <footer className="footer-containers">
            <h2 className="footer-name">Aaron Halangoda</h2>
            <h2 className="footer-sid">n11285672</h2>
            <h2 className="footer-msg">The World of Volcanos</h2>
            <h4 className="footer-nice">Hope you have an amazing</h4>
        </footer>
    );
}

export default Footer;